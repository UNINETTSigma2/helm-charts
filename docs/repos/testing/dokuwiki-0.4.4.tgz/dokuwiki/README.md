# DokuWiki

[DokuWiki](https://www.dokuwiki.org) is a standards-compliant, simple to use wiki optimized for creating documentation. It is targeted at developer teams, workgroups, and small companies. All data is stored in plain text files, so no database is required.

### Advanced
This application creates a [DokuWiki](https://github.com/Uninett/appstore-app-dokuwiki) instance using the following Dockerfiles:
  - [quay.io/Uninett/goidc-proxy](https://github.com/Uninett/goidc-proxy/blob/master/Dockerfile)
  - [quay.io/Uninett/dokuwiki](https://github.com/Uninett/helm-charts-dockerfiles/blob/master/dokuwiki/Dockerfile)
